package com.ibm.packages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class MoneyControl {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		WebDriverWait wait= new WebDriverWait(driver,60);
		driver.navigate().to("https://moneycontrol.com");	
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		WebElement Stock= driver.findElement(By.xpath("//a[@href='//www.moneycontrol.com/india/stockpricequote/']"));
		Stock.click();
		WebElement CompanyA= driver.findElement(By.xpath("//<a href='india/stockpricequote/A']"));
		CompanyA.click();
		
		

	}

}
