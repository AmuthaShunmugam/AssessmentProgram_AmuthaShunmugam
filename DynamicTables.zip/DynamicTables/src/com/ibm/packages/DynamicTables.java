package com.ibm.packages;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class DynamicTables {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		WebDriverWait wait= new WebDriverWait(driver,60);
		driver.navigate().to("https://datatables.net");	
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		WebElement show= driver.findElement(By.xpath("//option[@value='100']"));
		show.click();
		List <WebElement> rows= driver.findElements(By.xpath("//table[@id='example']/tbody/tr[1]/td"));
		int row=rows.size();
		System.out.println("The row count is:" +row);
		WebElement age=driver.findElement(By.xpath("//table[@id='example']/tbody/tr[1]/td[4]"));
			for(int i = 1;i<=100;i++)
					{
			WebElement name= driver.findElement(By.xpath("//table[@id='example']/tbody/tr[("+i+")]/td[1]"));
		    String Name= name.getText();
		    System.out.println(Name);
		    name.click();
		    WebElement Salary= driver.findElement(By.xpath("//table[@id='example']/tbody/tr[("+(i+1)+")]/td[1]"));
		    String salary= Salary.getText().trim().replace("$", "").replace(",","");
		    System.out.println(salary);
		    name.click();
		    
		    
		}
		
		
		}

}
